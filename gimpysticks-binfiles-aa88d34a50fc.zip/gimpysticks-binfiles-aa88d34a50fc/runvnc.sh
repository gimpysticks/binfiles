#!/bin/sh
/usr/bin/x11vnc -display :0 -reopen -avahi -shared -forever -rfbauth /home/$USER/.vnc/passwd
