#!/bin/sh
echo -e $USERPASS|sudo -S /usr/local/bin/Tickeys &
