#!/bin/sh
xinput disable 'Cirque Corporation 9925 AG Touchpad'
xinput enable 'Cirque Corporation 9925 AG Touchpad'

