#!/bin/sh
/usr/bin/redshift-gtk &
