#!/bin/sh

if [ $# -eq 0 ]
   then
       echo "Missing .py file argument"
else
       cat /home/sticks/snipets/shebangpy >> "$1" && chmod +x "$1" && vim "$1"
fi

