#/bin/bash
cp -urf /home/sticks/.gvfs/usb_hdd_1\ on\ 192.168.1.14/srv/pdf/* /home/sticks/.gvfs/srvfiles\ on\ 192.168.1.14/pdfs/ &
cp -urf /home/sticks/.gvfs/usb_hdd_1\ on\ 192.168.1.14/srv/scripts/* /home/sticks/.gvfs/srvfiles\ on\ 192.168.1.14/scripts/ &
