#!/bin/bash
python3 $HOME/src/pythonfiles/random_mc_seed/main.py

