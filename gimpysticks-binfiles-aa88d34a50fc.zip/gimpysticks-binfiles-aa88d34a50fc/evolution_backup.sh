!#/bin/bash
tar -czf /mnt/server-homes/sticks/evolution-backup.tar.gz /home/sticks/.evolution
tar -czf /home/sticks/Ubuntu\ One/evolution-backup.tar.gz /home/sticks/.evolution

