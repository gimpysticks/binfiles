echo -e "PgFc"\!"qLr99\$B"|sudo -S nmap -sP 192.168.0.0/24
