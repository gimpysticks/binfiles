#!/bin/sh
# mkdir -p ~/.google/chrome/backup
# mv ~/.config/google-chrome/Default/ ~/.google/chrome/backup
# mv ~/.cache/google-chrome ~/.google/chrome/backup
rm -rf ~/.config/google-chrome/Default/
rm -rf ~/.cache/google-chrome
