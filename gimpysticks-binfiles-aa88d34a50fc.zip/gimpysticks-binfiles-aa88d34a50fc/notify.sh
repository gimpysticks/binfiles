#!/bin/sh
notify-send 'Take a leak' -t 30000
