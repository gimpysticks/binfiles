sudo useradd -m -u 1001 -s /bin/bash --comment "Michelle Walls" mwalls4464
echo "mwalls4464:Viola119"|sudo chpasswd
sudo usermod -aG wheel mwall4464
sudo useradd -m -u 1002 -s /bin/bash --comment "Jim Kilbane" jimpkilbane
echo "jimpkilbane:nedheadJPK92865"|sudo chpasswd
sudo usermod -aG wheel jimpkilbane
sudo useradd -m -u 1003 -s /bin/bash --comment "Nick Walls" nickwalls
echo "nickwalls:nick4407"|sudo chpasswd
sudo usermod -aG wheel nickwalls
sudo useradd -m -u 1004 -s /bin/bash --comment "Caydence Walls" wallscayde
echo "wallscayde:04272009"|sudo chpasswd
sudo usermod -aG wheel wallscayde
sudo useradd -m -u 1005 -s /bin/bash --comment "Mason Walls" wallsmason55
echo "wallsmason55:mason91914"|sudo chpasswd
sudo usermod -aG wheel wallsmason55
sudo useradd -m -u 1007 -s /bin/bash --comment "Amanda Tapp" wallsa713
echo "wallsa713:SuperGirl713"|sudo chpasswd
sudo usermod -aG wheel wallsa713
sudo useradd -m -u 1009 -s /bin/bash --comment "David Ely" dely
echo "dely:PassWord12345"|sudo chpasswd
sudo usermod -aG wheel dely
sudo useradd -m -u 1010 -s /bin/bash --comment "Natalie Molony" molonynatalie
echo "molonynatalie:Natalie624*"|sudo chpasswd
sudo usermod -aG wheel molonynatalie
