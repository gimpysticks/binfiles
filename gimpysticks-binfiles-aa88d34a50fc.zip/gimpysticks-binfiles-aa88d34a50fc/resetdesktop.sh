killall -HUP cinnamon


