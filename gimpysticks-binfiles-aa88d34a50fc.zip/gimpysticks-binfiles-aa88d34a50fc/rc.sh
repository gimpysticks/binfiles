#!/bin/sh
killall -HUP cinnamon

