#!/bin/sh
#Default Cities
#City_ID Antwerpen:2803138
#City_ID Covington:4288809

sed -i 's/2803138/4288809/g' *Weather*.conkyrc
sed -i 's/metric/imperial/g' *Weather*.conkyrc

