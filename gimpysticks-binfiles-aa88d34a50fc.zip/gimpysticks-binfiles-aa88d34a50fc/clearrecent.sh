#!/bin/sh
cat /home/sticks/.local/share/recently-used.xbel>/home/sticks/Documents/recent-files.xbel
rm /home/sticks/.local/share/recently-used.xbel
touch /home/sticks/.local/share/recently-used.xbel
