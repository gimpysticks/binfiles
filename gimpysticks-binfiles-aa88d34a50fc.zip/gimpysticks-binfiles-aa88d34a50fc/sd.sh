#!/bin/sh
echo -e $USERPASS|sudo -S systemctl poweroff

