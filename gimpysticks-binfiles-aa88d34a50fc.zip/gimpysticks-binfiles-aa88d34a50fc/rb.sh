#!/bin/sh
echo $USERPASS|sudo -S systemctl reboot
