exec sh -c "source /home/$USER/venv3_5/bin/activate"
