#!/bin/sh
#cp /home/sticks/WindowsDeveloperPreview-*.iso /mnt/server-homes/sticks
#rm /home/sticks/*.iso
cp -ar /home/sticks/ /media/FB90-E0B4

