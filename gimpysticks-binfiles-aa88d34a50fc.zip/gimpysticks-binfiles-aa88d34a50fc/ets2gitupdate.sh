#!/bin/sh
cd /home/sticks/.local/share/Euro\ Truck\ Simulator\ 2
git add -A
git commit -m "`date`"
git push origin master
