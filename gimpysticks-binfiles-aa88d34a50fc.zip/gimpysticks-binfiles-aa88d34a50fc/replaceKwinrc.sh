#!/bin/sh
cp /mnt/backup/desktop/sticks/.config/kwinrc /home/sticks/.config/
cp /mnt/backup/desktop/sticks/.config/kwinrulesrc /home/sticks/.config/
