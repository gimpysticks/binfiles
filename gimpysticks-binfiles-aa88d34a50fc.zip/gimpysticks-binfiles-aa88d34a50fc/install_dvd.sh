#!/bin/sh
sudo apt-get install libdvd-pkg
sudo dpkg-reconfigure libdvd-pkg

