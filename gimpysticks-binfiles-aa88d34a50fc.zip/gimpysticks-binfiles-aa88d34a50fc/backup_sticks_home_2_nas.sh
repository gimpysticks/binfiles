#!/bin/sh
/usr/bin/rsync -r -t -v -p --delete -l -H -s /home/sticks/ /mnt/backup/desktop/sticks
