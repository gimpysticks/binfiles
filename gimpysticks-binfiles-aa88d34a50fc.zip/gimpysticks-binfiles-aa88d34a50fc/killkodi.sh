#!/bin/sh
kill -9 $(pgrep -f kodi.bin)

