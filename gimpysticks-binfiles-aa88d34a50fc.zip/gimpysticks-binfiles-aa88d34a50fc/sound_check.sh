#!/bin/sh
echo "Testing testing one two three check check"|espeak
