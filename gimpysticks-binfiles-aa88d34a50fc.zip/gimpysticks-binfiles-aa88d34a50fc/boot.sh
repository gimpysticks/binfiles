#!/bin/sh
echo -e "PgFc"\!"qLr99\$B"|sudo -S reboot
