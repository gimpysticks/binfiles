#!/bin/sh
xset -display :0 dpms force "$1"
