#!/bin/sh

DEVICE="Wacom Bamboo Craft Finger pad"

# Padtaste ganz oben = Button 1
xsetwacom set "$DEVICE" Button 1 "key ctrl shift greater"

# Padtaste mitte oben = Button 9
xsetwacom set "$DEVICE" Button 9 "key ctrl z"

# Padtaste mitte unten = Button 8
xsetwacom set "$DEVICE" Button 8 "key ctrl y"

# Padtaste ganz unten = Button 3
xsetwacom set "$DEVICE" Button 3 "key ctrl shift l"
