#!/bin/sh
wmctrl -l
