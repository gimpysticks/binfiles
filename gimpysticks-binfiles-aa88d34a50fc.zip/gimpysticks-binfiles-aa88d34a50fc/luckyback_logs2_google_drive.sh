#!/bin/sh
/usr/bin/rsync -av "/home/sticks/.luckyBackup/logs/" "/home/sticks/gimpysticks@gmail.com/luckybackup/"
