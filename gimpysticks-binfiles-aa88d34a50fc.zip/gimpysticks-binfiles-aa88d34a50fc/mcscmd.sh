#!/bin/sh
tmux send-keys -t 'minecraft' "$1" Enter
