#!/bin/sh
echo -e $USERPASS | sudo -S vim /etc/lightdm/lightdm.conf

