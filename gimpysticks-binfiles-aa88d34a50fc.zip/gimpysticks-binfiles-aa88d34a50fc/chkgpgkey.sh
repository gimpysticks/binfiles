#!/bin/sh
gpg --export-secret-keys -a gimpysticks@gmail.com > /dev/null && echo OK
