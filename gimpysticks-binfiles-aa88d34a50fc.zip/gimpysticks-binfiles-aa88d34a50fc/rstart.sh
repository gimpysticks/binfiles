#!/bin/sh
echo "gimpysticks\n"|sudo -S shutdown -r -f now



