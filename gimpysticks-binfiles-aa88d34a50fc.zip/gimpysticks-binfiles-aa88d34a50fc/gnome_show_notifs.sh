dbus-monitor "interface='org.freedesktop.Notifications'"|grep --line-buffered  "member=Notify\|string"

