#!/bin/sh
conky -c /home/sticks/.config/conky/vision/Z333-vision.conkyrc
