#!/bin/sh
export DISPLAY=:0
/usr/bin/google-chrome --app=https://www.broadcastify.com/listen/ctid/996/web
