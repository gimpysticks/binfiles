#!/bin/sh
setxkbmap -option "caps:escape"
