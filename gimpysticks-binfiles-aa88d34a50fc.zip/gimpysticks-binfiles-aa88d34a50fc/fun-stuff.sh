bin/bash
#set -e

# remember : toilet -f mono12 -F metal ArcoLinux
#sudo add-apt-repository ppa:ytvwld/asciiquarium
#sudo apt-get update
#sudo apt install -y asciiquarium 
#sudo apt install -y cmatrix 
#sudo snap install cool-retro-term 
sudo apt install -y figlet fortune lolcat spd-say cowsay 
sudo apt install -y mc 
sudo apt install -y ranger 
sudo apt install -y sl 
package="bash-pipes"
sudo apt install -y $package
package="boxes"
sudo apt install -y $package
package="cava"
sudo apt install -y $package
package="gotop-bin"
sudo apt install -y $package
package="python-pywal"
sudo apt install -y $package
package="toilet"
sudo apt install -y $package
package="slurm"
sudo apt install -y $package
echo "Installing tty-clock"
package="tty-clock"
sudo apt install -y $package
