#!/bin/sh
nvim $1-$(date +%m-%d-%Y).txt
