#/bin/bash
rsync -rz /home/sticks/.gvfs/usb_hdd_1\ on\ 192.168.1.14/srv/movies/* /home/sticks/.gvfs/media\ on\ 192.168.1.14/Videos/

