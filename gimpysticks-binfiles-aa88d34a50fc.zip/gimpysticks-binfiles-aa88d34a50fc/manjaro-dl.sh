#1!/bin/bash

notify-send "manjarolinux download Starting";
cd /home/sticks/images;
wget -c http://sourceforge.net/projects/manjarolinux/files/release/16.06-rc1/xfce/manjaro-xfce-16.06-rc1-x86_64.iso;
wget -c http://sourceforge.net/projects/manjarolinux/files/release/16.06-rc1/kde/manjaro-kde-16.06-rc1-x86_64.iso;
wget -c http://sourceforge.net/projects/manjarolinux/files/release/16.06-rc1/netinstall/manjaro-net-16.06-rc1-x86_64.iso;
notify-send "manjarolinux download done";
