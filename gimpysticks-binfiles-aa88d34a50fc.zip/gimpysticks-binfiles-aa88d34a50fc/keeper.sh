#!/bin/sh
cd /home/sticks/KeeperDesktop
java -Xms256m -Xmx1g -jar KeeperDesktop.jar
