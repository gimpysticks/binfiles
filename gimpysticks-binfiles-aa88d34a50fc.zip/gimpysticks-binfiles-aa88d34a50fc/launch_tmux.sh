#!/bin/sh
tmux attach||tmux new
