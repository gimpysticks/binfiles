#!/bin/sh
 killall espeak-ng
 xclip -o|espeak-ng -s 175
