#!/bin/bash
i3lock-wrapper -l
