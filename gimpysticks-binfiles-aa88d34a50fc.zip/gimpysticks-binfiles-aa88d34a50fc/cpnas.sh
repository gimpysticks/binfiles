#/bin/bash
cp -uRf /home/sticks/.gvfs/usb_hdd_1\ on\ 192.168.1.14/srv/music/* /home/sticks/.gvfs/media\ on\ 192.168.1.14/Music/ &
cp -uRf /home/sticks/.gvfs/usb_hdd_1\ on\ 192.168.1.14/srv/images/* /home/sticks/.gvfs/media\ on\ 192.168.1.14/Pictures/ &
cp -uRf /home/sticks/.gvfs/usb_hdd_1\ on\ 192.168.1.14/home/* /home/sticks/.gvfs/srvfiles\ on\ 192.168.1.14/ &
