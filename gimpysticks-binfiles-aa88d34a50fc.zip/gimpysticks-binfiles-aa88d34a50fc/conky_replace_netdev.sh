#!/bin/sh
#Default netcard

sed -i 's/enp0s31f6/enp0s25/g' *.conkyrc
# sed -i 's/wls33/enp0s25/g' *.conkyrc
